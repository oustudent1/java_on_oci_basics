package webservice;

import javax.jws.WebService;

@WebService
public class Java2WSDL {

    public String getName(){

        return "joe";
    }
}
