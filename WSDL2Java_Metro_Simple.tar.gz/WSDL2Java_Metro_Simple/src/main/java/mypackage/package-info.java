@javax.xml.bind.annotation.XmlSchema(namespace = "http://null", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package mypackage;
