package io.helidon.hr.app.mp.domain;

import javax.json.bind.annotation.JsonbCreator;
import javax.json.bind.annotation.JsonbProperty;
import java.util.List;
import java.util.UUID;

public final class Department {
    private final String id;
    private final String name;
    private final String regionId;
    private List<String> employees;


    public Department(String id, String name, String regionId) {
        this.id = id;
        this.name = name;
        this.regionId = regionId;
    }

    @JsonbCreator
    public static Department of(@JsonbProperty("id") String id, @JsonbProperty("name") String name,
                              @JsonbProperty("region_id") String regionId) {
        if (id == null || id.trim().equals("")) {
            id = UUID.randomUUID().toString();
        }
        return new Department(id, name, regionId);

    }


    public String getId() {
        return id;
    }

    public String getName() {

        return name;
    }

    public String getRegionId() {
        return regionId;
    }

    public void addEmployee(String empId){
        employees.add(empId);
    }

}
