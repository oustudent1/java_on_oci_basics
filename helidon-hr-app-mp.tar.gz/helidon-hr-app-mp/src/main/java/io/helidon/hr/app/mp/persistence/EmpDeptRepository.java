package io.helidon.hr.app.mp.persistence;

import io.helidon.config.Config;
import io.helidon.hr.app.mp.domain.Department;
import io.helidon.hr.app.mp.domain.Employee;

import java.util.List;

public interface EmpDeptRepository {
    public static EmpDeptRepository create(String driverType, Config config) {
        switch (driverType) {
            case "Array":
                return new EmpDeptRepositoryImpl();
        /*case "Oracle":
            return new EmployeeRepositoryImplDB(config);*/
            default:
                // Array is default
                return new EmpDeptRepositoryImpl();
        }
    }

    public List<Employee> employees();
    public List<Employee> getByLastName(String lastName);
    public List<Employee> getByTitle(String title);
    public List<Employee> getByDepartment(String department);
   // public List<Employee> getByDepartment(int deptId);
    public Employee save(Employee employee); // Add new employee
    public Employee update(Employee updatedEmployee, String id);
    public void deleteById(String id);
    public Employee getById(String id);
    public boolean isIdFound(String id);
    public int getEmployeeCount();

    // department api
    public Department getDepartment(String dept);
}
