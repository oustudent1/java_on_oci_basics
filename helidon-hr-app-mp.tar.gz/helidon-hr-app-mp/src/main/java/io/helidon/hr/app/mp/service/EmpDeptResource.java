package io.helidon.hr.app.mp.service;

import java.util.*;
import java.util.logging.Logger;


import io.helidon.config.Config;
import io.helidon.hr.app.mp.domain.Department;
import io.helidon.hr.app.mp.domain.Employee;
import io.helidon.hr.app.mp.persistence.EmpDeptRepository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;


@Path("/")
@ApplicationScoped
public class EmpDeptResource /*implements Service */{

    private static final JsonBuilderFactory JSON = Json.createBuilderFactory(Collections.emptyMap());

    private EmpDeptRepository empDeptRepo;
    private static final Logger LOGGER = Logger.getLogger(EmpDeptResource.class.getName());

    private EmpDeptProvider employeeProvider;

    @Inject
    public EmpDeptResource(Config config, EmpDeptProvider anEmployeeProvider) {
        employeeProvider = anEmployeeProvider;
        empDeptRepo = EmpDeptRepository.create(config.get("app.drivertype").asString().orElse("Array"), config);
    }


@Path("/employee/all")
@GET
@Produces(MediaType.APPLICATION_JSON)
    public Collection<Employee> employees() {
        LOGGER.fine("getAll");
        return empDeptRepo.employees();

    }

    @Path("/employee/{lastName}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Employee getByLastName(@PathParam("lastName") String lastName) {
        LOGGER.fine("getByLastName");

            List<Employee> emps = this.empDeptRepo.getByLastName(lastName);
            return emps.get(0);


    }

@Path("/employee/title/{title}")
@GET
@Produces(MediaType.APPLICATION_JSON)
   public Collection<Employee> getByTitle(@PathParam("title") String title) {
        LOGGER.fine("getByTitle");
        return empDeptRepo.getByTitle(title);
    }

    @Path("/employee/id/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Employee  getEmployeeById(@PathParam("id") String id) {
        LOGGER.fine("getEmployeeById");
        // If invalid, response handled in isValidId. Keeping DRY
       // if (isValidId(response, request.path().param("id"))) {
        return empDeptRepo.getById(id);
            //response.status(200).send(employee);
       // }
    }

    /**
     * Saves a new employee.
     */
    @Path("/employee")
    @POST
    @Consumes({MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
    @Produces(MediaType.APPLICATION_JSON)
    public String save(String request) {
        LOGGER.fine("save");

        Jsonb jsonb = JsonbBuilder.create();
        Employee newEmp = jsonb.fromJson(request, Employee.class);
        //System.out.println("*** Emp Count Before = " + employees.getEmployeeCount());
        empDeptRepo.save(newEmp);
       // System.out.println("*** Emp Count After = " + employees.getEmployeeCount());

        return empDeptRepo.getByLastName("Duke").get(0).getId();//newEmp.getFirstName();

/*        request.content().as(Employee.class)
                .thenApply(e -> Employee.of(null, e.getFirstName(), e.getLastName(), e.getEmail(), e.getPhone(),
                        e.getBirthDate(), e.getTitle(), e.getDepartment()))
                .thenApply(this.employees::save).thenCompose(p -> response.status(201).send());*/
    }

    /**
     * Updates an existing employee.
     */
    @Path("/employee")
    @PUT
    public void update(String request) {
        LOGGER.fine("update");
        Jsonb jsonb = JsonbBuilder.create();
        Employee newEmp = jsonb.fromJson(request, Employee.class);
        empDeptRepo.update(newEmp, newEmp.getId());
    }

    /**
     * Deletes an existing employee.
     */
    @Path("/employee/{id}")
    @DELETE

    public void delete(@PathParam("id") String id) {
        LOGGER.fine("delete");
        empDeptRepo.deleteById(id);
    }
// Department API handlers

    @Path("/dept/{dept}/employees")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Employee> getByDepartment(@PathParam("dept") String dept) {
        LOGGER.fine("getByDepartment");
        //return createResponse( employees.getByDepartment(dept));
        return  empDeptRepo.getByDepartment(dept);
       /* if (isValidQueryStr(response, request.path().param("name"))) {
            response.status(200).send(this.employees.getByDepartment(request.path().param("name")));
        }*/
    }

    @Path("/dept/{dept}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Department getDepartment(@PathParam("dept") String dept){
        return empDeptRepo.getDepartment(dept);
    }
    /**
     * Validates the parameter.
     * @param response the server response
     * @param nameStr
     * @return
     */
    /*private boolean isValidQueryStr(ServerResponse response, String nameStr) {
        Map<String, String> errorMessage = new HashMap<>();
        if (nameStr == null || nameStr.isEmpty() || nameStr.length() > 100) {
            errorMessage.put("errorMessage", "Invalid query string");
            response.status(400).send(errorMessage);
            return false;
        } else {
            return true;
        }
    }*/

    /**
     * Validates if the ID of the employee exists.
     * @return
     */
    /*private boolean isValidId(ServerResponse response, String idStr) {
        Map<String, String> errorMessage = new HashMap<>();
        if (idStr == null || idStr.isEmpty()) {
            errorMessage.put("errorMessage", "Invalid query string");
            response.status(400).send(errorMessage);
            return false;
        } else if (this.employees.isIdFound(idStr)) {
            return true;
        } else {
            errorMessage.put("errorMessage", "ID " + idStr + " not found");
            response.status(404).send(errorMessage);
            return false;
        }
    }*/

    private JsonObject createResponse(String who) {
        String msg = String.format("%s %s!", employeeProvider.getMessage(), who);

        return JSON.createObjectBuilder()
                .add("message", msg)
                .build();
    }


/*

    EmployeeResource(Config config) {
        employees = EmployeeRepository.create(config.get("app.drivertype").asString().orElse("Array"), config);
    }*/


 /*   @GET
    @Produces(MediaType.APPLICATION_JSON)
    public JsonObject getDefaultMessage() {
        Employee emp = new Employee("1000", "Jerry", "Garcia","jg@dead.net","415-555-1212", "1/1/1947","lead guitar","music");

        return createResponse( employees.getByLastName("Torp").get(0).getFirstName());
    }*/


   /* public EmployeeResource() {
        this.employees = null;
    }*/

}
