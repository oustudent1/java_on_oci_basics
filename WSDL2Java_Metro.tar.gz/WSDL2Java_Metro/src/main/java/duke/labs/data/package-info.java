@javax.xml.bind.annotation.XmlSchema(namespace = "urn:duke:labs:data", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package duke.labs.data;
