package io.helidon.examples.quickstart.mp;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;


import io.helidon.config.Config;
import io.helidon.webserver.Routing;
import io.helidon.webserver.ServerRequest;
import io.helidon.webserver.ServerResponse;
import io.helidon.webserver.Service;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/employee")
@RequestScoped
public class EmployeeResource /*implements Service */{

    private static final JsonBuilderFactory JSON = Json.createBuilderFactory(Collections.emptyMap());

    private  EmployeeRepository employees;
    private static final Logger LOGGER = Logger.getLogger(EmployeeResource.class.getName());

    private  EmployeeProvider employeeProvider;

    @Inject
    public EmployeeResource(Config config, EmployeeProvider anEmployeeProvider) {
        employeeProvider = anEmployeeProvider;
        employees = EmployeeRepository.create(config.get("app.drivertype").asString().orElse("Array"), config);
    }

/*

    EmployeeResource(Config config) {
        employees = EmployeeRepository.create(config.get("app.drivertype").asString().orElse("Array"), config);
    }*/


    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public JsonObject getDefaultMessage() {
        Employee emp = new Employee("1000", "Jerry", "Garcia","jg@dead.net","415-555-1212", "1/1/1947","lead guitar","music");

        return createResponse( employees.getByLastName("Torp").get(0).getFirstName());
    }


   /* public EmployeeResource() {
        this.employees = null;
    }*/
    /* public void update(Routing.Rules rules) {
        rules.get("/", this::getAll)
                .get("/lastname/{name}", this::getByLastName)
                .get("/department/{name}", this::getByDepartment)
                .get("/title/{name}", this::getByTitle)
                .post("/", this::save)
                .get("/{id}", this::getEmployeeById)
                .put("/{id}", this::update)
                .delete("/{id}", this::delete);
    }*/
    /**
     * Gets all the employees.
     * @param request  the server request
     * @param response the server response
     */
    /*private void getAll(final ServerRequest request, final ServerResponse response) {
        LOGGER.fine("getAll");
        List<Employee> allEmployees = this.employees.getAll();
        response.send(allEmployees);
    }*/

    /**
     * Gets the employees by the last name specified in the parameter.
     * @param request  the server request
     * @param response the server response
     */
    /*private void getByLastName(final ServerRequest request, final ServerResponse response) {
       // System.out.println("*** Get EMp by Lasdt name - Service - pre log");
        LOGGER.fine("getByLastName");
        //System.out.println("*** Get EMp by Lasdt name - Service - post log");
        // Invalid query strings handled in isValidQueryStr. Keeping DRY
        if (isValidQueryStr(response, request.path().param("name"))) {
            String empStr = request.path().param("name");
            List<Employee> emps = this.employees.getByLastName(empStr);
          //  response.status(200).send(this.employees.getByLastName(request.path().param("name")));
            Employee emp = emps.get(0);
            response.status(200).send(emp);
        }
    }*/

    /**
     * Gets the employees by the title specified in the parameter.
     * @param request  the server request
     * @param response the server response
     */
   /* private void getByTitle(final ServerRequest request, final ServerResponse response) {
        LOGGER.fine("getByTitle");
        if (isValidQueryStr(response, request.path().param("name"))) {
            response.status(200).send(this.employees.getByTitle(request.path().param("name")));
        }
    }*/

    /**
     * Gets the employees by the department specified in the parameter.
     * @param request  the server request
     * @param response the server response
     */
    /*private void getByDepartment(final ServerRequest request, final ServerResponse response) {
        LOGGER.fine("getByDepartment");
        if (isValidQueryStr(response, request.path().param("name"))) {
            response.status(200).send(this.employees.getByDepartment(request.path().param("name")));
        }
    }*/

    /**
     * Gets the employees by the ID specified in the parameter.
     * @param request  the server request
     * @param response the server response
     */
    /*private void getEmployeeById(ServerRequest request, ServerResponse response) {
        LOGGER.fine("getEmployeeById");
        // If invalid, response handled in isValidId. Keeping DRY
        if (isValidId(response, request.path().param("id"))) {
            Employee employee = this.employees.getById(request.path().param("id"));
            response.status(200).send(employee);
        }
    }*/

    /**
     * Saves a new employee.
     * @param request  the server request
     * @param response the server response
     */
    /*private void save(ServerRequest request, ServerResponse response) {
        LOGGER.fine("save");
        request.content().as(Employee.class)
                .thenApply(e -> Employee.of(null, e.getFirstName(), e.getLastName(), e.getEmail(), e.getPhone(),
                        e.getBirthDate(), e.getTitle(), e.getDepartment()))
                .thenApply(this.employees::save).thenCompose(p -> response.status(201).send());
    }*/

    /**
     * Updates an existing employee.
     * @param request  the server request
     * @param response the server response
     */
    /*private void update(ServerRequest request, ServerResponse response) {
        LOGGER.fine("update");
        if (isValidId(response, request.path().param("id"))) {
            request.content().as(Employee.class).thenApply(e -> {
                return this.employees.update(Employee.of(e.getId(), e.getFirstName(), e.getLastName(), e.getEmail(),
                        e.getPhone(), e.getBirthDate(), e.getTitle(), e.getDepartment()), request.path().param("id"));
            }).thenCompose(p -> response.status(204).send());
        }
    }*/

    /**
     * Deletes an existing employee.
     * @param request  the server request
     * @param response the server response
     */
    /*private void delete(final ServerRequest request, final ServerResponse response) {
        LOGGER.fine("delete");
        if (isValidId(response, request.path().param("id"))) {
            this.employees.deleteById(request.path().param("id"));
            response.status(204).send();
        }
    }*/

    /**
     * Validates the parameter.
     * @param response the server response
     * @param nameStr
     * @return
     */
    /*private boolean isValidQueryStr(ServerResponse response, String nameStr) {
        Map<String, String> errorMessage = new HashMap<>();
        if (nameStr == null || nameStr.isEmpty() || nameStr.length() > 100) {
            errorMessage.put("errorMessage", "Invalid query string");
            response.status(400).send(errorMessage);
            return false;
        } else {
            return true;
        }
    }*/

    /**
     * Validates if the ID of the employee exists.
     * @return
     */
    /*private boolean isValidId(ServerResponse response, String idStr) {
        Map<String, String> errorMessage = new HashMap<>();
        if (idStr == null || idStr.isEmpty()) {
            errorMessage.put("errorMessage", "Invalid query string");
            response.status(400).send(errorMessage);
            return false;
        } else if (this.employees.isIdFound(idStr)) {
            return true;
        } else {
            errorMessage.put("errorMessage", "ID " + idStr + " not found");
            response.status(404).send(errorMessage);
            return false;
        }
    }*/

    private JsonObject createResponse(String who) {
        String msg = String.format("%s %s!", employeeProvider.getMessage(), who);

        return JSON.createObjectBuilder()
                .add("message", msg)
                .build();
    }

}
