package io.helidon.examples.quickstart.mp;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import java.util.Set;


/*@ApplicationScoped
@ApplicationPath("/")*/
public class EmployeeApplication {


  /*  @Override
    public Set<Class<?>> getClasses() {
        // here we have two classes to operate on, the store front, and the
        // configuration manager
        return CollectionsHelper.setOf(EmployeeResource.class);
    }*/

}
